package com.ODentist.Day13.HomeWork.Type2SDC;

public class MyRunnable{
    public static int a=0;
    public synchronized void singleCount() throws InterruptedException {
        while (a<=100)
        {
            if (a%2==1){
                System.out.println(Thread.currentThread().getName()+"  "+a);
                a++;
            }else {
                this.wait();
                this.notifyAll();
            }
        }
    }
    public synchronized void doubleCount() throws InterruptedException {
        if (a%2==0){
            System.out.println(Thread.currentThread().getName()+"  "+a);
            a++;
        }else {
            this.wait();
            this.notifyAll();
        }
    }
}
