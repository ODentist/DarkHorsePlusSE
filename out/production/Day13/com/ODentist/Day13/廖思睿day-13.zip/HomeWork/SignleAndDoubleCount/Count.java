package com.ODentist.Day13.HomeWork.SignleAndDoubleCount;

public class Count {
    public static int count=0;
    public static final Object lock = new Object();

}
