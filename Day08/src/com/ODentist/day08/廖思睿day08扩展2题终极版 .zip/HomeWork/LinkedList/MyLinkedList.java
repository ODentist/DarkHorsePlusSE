package com.ODentist.day08.HomeWork.LinkedList;

public interface MyLinkedList {
    public void addFirst(Student student);
}
