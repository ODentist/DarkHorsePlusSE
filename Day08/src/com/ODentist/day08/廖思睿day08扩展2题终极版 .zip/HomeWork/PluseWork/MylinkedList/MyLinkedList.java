package com.ODentist.day08.HomeWork.PluseWork.MylinkedList;

import java.util.LinkedList;
public interface MyLinkedList {
   void add(Student node);
   Student get(int index);
}
